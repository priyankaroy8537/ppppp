package com.proy.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proy.entity.StudentMarks;
import com.proy.repository.StudentMarksRepository;

@Service
public class StudentMarksService {

    @Autowired
    private StudentMarksRepository studentMarksRepository;

    public StudentMarks getStudentMarksById(Long id) {
        return studentMarksRepository.findById(id).orElse(null);
    }

    public StudentMarks createStudentMarks(StudentMarks studentMarks) {
        return studentMarksRepository.save(studentMarks);
    }
}

