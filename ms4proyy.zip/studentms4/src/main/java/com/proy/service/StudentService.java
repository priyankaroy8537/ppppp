package com.proy.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proy.entity.Student;
import com.proy.repository.StudentRepository;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public Student getStudentById(Long id) {
        return studentRepository.findById(id).orElse(null);
    }

    public List<Student> getStudentsByLname(String lname) {
        return studentRepository.findByLname(lname);
    }

    public Student createStudent(Student student) {
        return studentRepository.save(student);
    }
}

